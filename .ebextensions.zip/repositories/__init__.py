"""Data access layer for the project."""
